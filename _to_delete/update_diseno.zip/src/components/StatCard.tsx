export default function StatCard({
  label,
  value,
  tone = "neutral",
}: {
  label: string;
  value: string | number | null;
  tone?: "critical" | "warning" | "ok" | "neutral";
}) {
  const sinDato = value === null || value === undefined;

  const BORDE: Record<string, string> = {
    critical: "border-critico",
    warning: "border-evaluacion",
    ok: "border-operativo",
    neutral: "border-tinta",
  };

  return (
    <div className={`bg-fondo-2 border-l-[5px] ${sinDato ? "border-linea-2" : BORDE[tone]} px-3.5 py-3`}>
      <div className={`text-2xl sm:text-3xl font-bold tabular-nums leading-none ${sinDato ? "text-gris" : "text-tinta"}`}>
        {sinDato ? "—" : value}
      </div>
      <div className="text-xs sm:text-sm font-semibold mt-1.5 text-tinta">{label}</div>
      {sinDato && <div className="text-[11px] text-gris mt-0.5">Sin dato confirmado</div>}
    </div>
  );
}
