import Link from "next/link";

const ACTIONS = [
  { href: "/donar", label: "Donar", icon: "🤝" },
  { href: "/albergues", label: "Albergues", icon: "🏠" },
  { href: "/reportar", label: "Reportar", icon: "📣" },
  { href: "/lineas-de-emergencia", label: "Emergencia", icon: "☎", critico: true },
];

export default function QuickActions() {
  return (
    <>
      {/* Barra fija inferior en móvil: las 4 acciones más urgentes a 1 tap */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-tinta border-t-[3px] border-critico grid grid-cols-4">
        {ACTIONS.map((a) => (
          <Link
            key={a.href}
            href={a.href}
            className={`flex flex-col items-center justify-center gap-0.5 py-2.5 text-[11px] font-semibold text-white text-center leading-tight ${
              a.critico ? "bg-critico" : "active:bg-tinta-2"
            }`}
          >
            <span className="text-base leading-none">{a.icon}</span>
            {a.label}
          </Link>
        ))}
      </nav>
      {/* Espaciador para que el contenido no quede oculto tras la barra fija */}
      <div className="md:hidden h-14" aria-hidden />
    </>
  );
}
