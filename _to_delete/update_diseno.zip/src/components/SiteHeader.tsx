import Link from "next/link";
import { meta } from "@/lib/data";
import { formatFecha } from "@/lib/data";

const NAV_LINKS = [
  { href: "/departamentos", label: "Departamentos" },
  { href: "/salud", label: "Salud" },
  { href: "/albergues", label: "Albergues" },
  { href: "/donar", label: "Donar" },
  { href: "/voluntariado", label: "Voluntariado" },
  { href: "/lineas-de-emergencia", label: "Líneas de emergencia" },
  { href: "/tramites", label: "Trámites" },
  { href: "/apoyo-privado", label: "Apoyo privado" },
  { href: "/fuentes", label: "Fuentes" },
];

export default function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 bg-fondo border-b border-linea">
      {/* Tira de evento: identidad institucional fija, siempre visible */}
      <div className="bg-tinta text-fondo-2 text-xs sm:text-sm px-4 py-1.5 text-center">
        {meta.evento} · Última actualización: {formatFecha(meta.ultima_actualizacion)}
      </div>
      <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
        <Link href="/" className="font-extrabold text-lg text-tinta shrink-0">
          Ayuda Suroccidente <span className="text-critico">·</span> Respuesta Terremoto
        </Link>
        <nav className="hidden md:flex flex-wrap gap-x-4 gap-y-1 text-sm font-medium text-tinta-3 justify-end">
          {NAV_LINKS.map((link) => (
            <Link key={link.href} href={link.href} className="hover:text-critico hover:underline underline-offset-4">
              {link.label}
            </Link>
          ))}
        </nav>
      </div>
      {/* Nav simplificada visible en móvil (scroll horizontal) */}
      <nav className="md:hidden flex gap-3 overflow-x-auto px-4 pb-2 text-sm font-medium text-tinta-3 whitespace-nowrap">
        {NAV_LINKS.map((link) => (
          <Link key={link.href} href={link.href} className="hover:text-critico">
            {link.label}
          </Link>
        ))}
      </nav>
    </header>
  );
}
