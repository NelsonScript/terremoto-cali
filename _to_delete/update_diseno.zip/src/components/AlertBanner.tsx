export default function AlertBanner() {
  return (
    <div role="alert" className="bg-critico text-white px-4 py-3 text-sm sm:text-base text-center font-semibold">
      Toda ayuda económica canalízala <strong>únicamente a través de la Cruz
      Roja Colombiana</strong>. No transfieras dinero a cuentas personales ni
      colectas no verificadas.
    </div>
  );
}
