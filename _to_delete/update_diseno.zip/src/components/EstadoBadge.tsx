import type { EstadoSemantico } from "@/lib/data";

const LABELS: Record<EstadoSemantico, string> = {
  critico: "Crítico",
  "en-evaluacion": "En evaluación",
  "sin-datos": "Sin datos",
};

const CLASSES: Record<EstadoSemantico, string> = {
  critico: "bg-critico text-white",
  "en-evaluacion": "bg-evaluacion text-white",
  "sin-datos": "bg-gris text-white",
};

export default function EstadoBadge({ estado }: { estado: EstadoSemantico }) {
  return (
    <span
      className={`inline-block text-[11px] font-bold uppercase tracking-wide px-2 py-0.5 whitespace-nowrap ${CLASSES[estado]}`}
    >
      {LABELS[estado]}
    </span>
  );
}
