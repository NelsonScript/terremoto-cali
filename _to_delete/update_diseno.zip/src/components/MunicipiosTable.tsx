"use client";

import { useMemo, useState } from "react";
import type { Municipio } from "@/lib/types";

export default function MunicipiosTable({ municipios }: { municipios: Municipio[] }) {
  const [query, setQuery] = useState("");

  const filtrados = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return municipios;
    return municipios.filter((m) => m.nombre.toLowerCase().includes(q));
  }, [municipios, query]);

  return (
    <div>
      {municipios.length > 5 && (
        <input
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Buscar municipio…"
          className="w-full sm:w-64 border border-tinta px-3 py-2 text-sm mb-3 bg-fondo text-tinta"
        />
      )}
      <div className="overflow-x-auto border border-linea">
        <table className="w-full text-sm">
          <thead>
            <tr>
              <th>Municipio</th>
              <th>Situación reportada</th>
            </tr>
          </thead>
          <tbody>
            {filtrados.map((m) => (
              <tr key={m.nombre}>
                <td className="font-bold whitespace-nowrap text-tinta">{m.nombre}</td>
                <td className="text-tinta-3">{m.nota}</td>
              </tr>
            ))}
            {filtrados.length === 0 && (
              <tr>
                <td colSpan={2} className="text-center text-gris">
                  Sin resultados para &quot;{query}&quot;.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
