import Link from "next/link";
import EstadoBadge from "@/components/EstadoBadge";
import { getEstadoDepartamento, formatNumero } from "@/lib/data";
import type { Departamento } from "@/lib/types";

export default function DepartamentosTable({ departamentos }: { departamentos: Departamento[] }) {
  return (
    <div className="overflow-x-auto border border-linea">
      <table className="w-full text-sm">
        <thead>
          <tr>
            <th>Departamento</th>
            <th className="text-right">Fallecidos</th>
            <th>Situación</th>
            <th>Estado</th>
          </tr>
        </thead>
        <tbody>
          {departamentos.map((d) => {
            const fallecidos = d.cifras_capital?.fallecidos ?? d.cifras_departamento_ungrd.fallecidos;
            const estado = getEstadoDepartamento(d);
            return (
              <tr key={d.id} className="hover:bg-fondo-2">
                <td>
                  <Link href={`/departamentos/${d.id}`} className="font-bold text-tinta hover:text-critico hover:underline">
                    {d.nombre}
                  </Link>
                  <div className="text-xs text-gris">Capital: {d.capital}</div>
                </td>
                <td className="text-right font-bold tabular-nums text-lg text-tinta">{formatNumero(fallecidos)}</td>
                <td className="text-tinta-3 max-w-xs">{d.resumen}</td>
                <td><EstadoBadge estado={estado} /></td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
