import type { Metadata } from "next";
import { getAlberguesYAcopio } from "@/lib/data";

export const metadata: Metadata = {
  title: "Albergues y puntos de acopio",
};

const TIPO_CLASSES: Record<string, string> = {
  "Albergue temporal": "bg-operativo text-white",
  "Punto de acopio": "bg-tinta text-white",
};

export default function AlberguesPage() {
  const items = getAlberguesYAcopio();

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-extrabold text-tinta mb-2">Albergues y puntos de acopio</h1>
      <p className="text-tinta-3 mb-6 max-w-2xl">
        Directorio de sitios habilitados para alojar a familias damnificadas
        y recibir donaciones. Se irá ampliando por departamento a medida que
        se habiliten nuevos puntos.
      </p>

      {items.length === 0 ? (
        <p className="text-gris">Aún no hay puntos registrados.</p>
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {items.map((a) => (
            <div key={`${a.tipo}-${a.nombre}`} className="border border-linea p-4">
              <div className="flex items-start justify-between gap-2">
                <span className="font-bold text-tinta">{a.nombre}</span>
                <span
                  className={`text-[11px] font-bold uppercase tracking-wide px-2 py-0.5 shrink-0 ${
                    TIPO_CLASSES[a.tipo] ?? "bg-gris text-white"
                  }`}
                >
                  {a.tipo}
                </span>
              </div>
              <div className="text-xs text-gris mt-1">{a.departamento}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
