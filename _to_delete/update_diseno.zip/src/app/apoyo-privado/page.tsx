import type { Metadata } from "next";
import { apoyoPrivado } from "@/lib/data";
import type { ApoyoPrivado } from "@/lib/types";

export const metadata: Metadata = {
  title: "Apoyo externo y del sector privado",
};

function Grupo({ tipo, items }: { tipo: string; items: ApoyoPrivado[] }) {
  if (items.length === 0) return null;
  return (
    <div className="mb-8">
      <h2 className="text-xs font-bold uppercase tracking-wide text-tinta-3 mb-2">{tipo}</h2>
      <div className="overflow-x-auto border border-linea">
        <table className="w-full text-sm">
          <tbody>
            {items.map((a) => (
              <tr key={a.organizacion}>
                <td className="font-bold whitespace-nowrap align-top text-tinta">{a.organizacion}</td>
                <td className="text-tinta-3">{a.aporte}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default function ApoyoPrivadoPage() {
  const internacional = apoyoPrivado.filter((a) => a.tipo === "Cooperación internacional");
  const privado = apoyoPrivado.filter((a) => a.tipo === "Sector privado");
  const interinstitucional = apoyoPrivado.filter((a) => a.tipo === "Cooperación interinstitucional");

  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-extrabold text-tinta mb-2">Apoyo externo y del sector privado</h1>
      <p className="text-tinta-3 mb-6 max-w-2xl">
        Países, empresas e instituciones que ya están aportando a la
        respuesta. Reconocerlos también sirve para que más se sumen.
      </p>

      <Grupo tipo="Cooperación internacional" items={internacional} />
      <Grupo tipo="Sector privado" items={privado} />
      <Grupo tipo="Cooperación interinstitucional" items={interinstitucional} />

      <p className="text-sm text-gris mt-2">
        ¿Tu empresa u organización quiere sumarse? Escríbenos a través del
        formulario de{" "}
        <a href="/voluntariado" className="underline hover:text-critico">voluntariado</a>.
      </p>
    </div>
  );
}
