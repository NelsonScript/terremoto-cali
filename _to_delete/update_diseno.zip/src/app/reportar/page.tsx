"use client";

import { useState, type FormEvent } from "react";
import EmergencyFormNotice from "@/components/EmergencyFormNotice";
import { useCrisisForm } from "@/lib/useCrisisForm";
import { departamentos } from "@/lib/data";

const TIPOS = [
  "Persona atrapada / desaparecida",
  "Edificio en riesgo",
  "Necesidad médica urgente",
  "Otro",
];

export default function ReportarPage() {
  const { status, errorMsg, submit, isFirebaseConfigured } = useCrisisForm("reportes");
  const [tipo, setTipo] = useState(TIPOS[0]);
  const [departamento, setDepartamento] = useState(departamentos[0]?.id ?? "");

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    submit({
      tipo,
      departamento,
      municipio: form.get("municipio"),
      descripcion: form.get("descripcion"),
      ubicacion: form.get("ubicacion"),
      contacto: form.get("contacto"),
    });
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-extrabold text-tinta mb-2">Reportar</h1>
      <p className="text-tinta-3 mb-6">
        Reporta una persona atrapada o desaparecida, un edificio en riesgo, o
        una necesidad médica urgente. El equipo coordinador revisa cada
        reporte.
      </p>

      <EmergencyFormNotice />

      {status === "success" ? (
        <div className="bg-operativo-suave border-l-[5px] border-operativo text-tinta p-5">
          Reporte enviado. Gracias — recuerda que para riesgo de vida
          inmediato debes llamar también a 119 o 123.
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-semibold mb-1 text-tinta" htmlFor="tipo">Tipo de reporte</label>
            <select
              id="tipo"
              value={tipo}
              onChange={(e) => setTipo(e.target.value)}
              className="w-full border border-tinta px-3 py-2 bg-fondo text-tinta"
            >
              {TIPOS.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-sm font-semibold mb-1 text-tinta" htmlFor="departamento">Departamento</label>
            <select
              id="departamento"
              value={departamento}
              onChange={(e) => setDepartamento(e.target.value)}
              className="w-full border border-tinta px-3 py-2 bg-fondo text-tinta"
            >
              {departamentos.map((d) => <option key={d.id} value={d.id}>{d.nombre}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-sm font-semibold mb-1 text-tinta" htmlFor="municipio">Municipio</label>
            <input
              id="municipio"
              name="municipio"
              type="text"
              placeholder="Ej: Cali, Quibdó, Dosquebradas…"
              className="w-full border border-tinta px-3 py-2 bg-fondo text-tinta"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold mb-1 text-tinta" htmlFor="descripcion">Descripción</label>
            <textarea
              id="descripcion"
              name="descripcion"
              required
              rows={4}
              className="w-full border border-tinta px-3 py-2 bg-fondo text-tinta"
              placeholder="Describe la situación con el mayor detalle posible"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold mb-1 text-tinta" htmlFor="ubicacion">Ubicación (dirección, barrio o punto de referencia)</label>
            <input
              id="ubicacion"
              name="ubicacion"
              type="text"
              className="w-full border border-tinta px-3 py-2 bg-fondo text-tinta"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold mb-1 text-tinta" htmlFor="contacto">Contacto (opcional)</label>
            <input
              id="contacto"
              name="contacto"
              type="text"
              placeholder="Teléfono o correo, si quieres que te contactemos"
              className="w-full border border-tinta px-3 py-2 bg-fondo text-tinta"
            />
          </div>

          {!isFirebaseConfigured && (
            <p className="text-xs text-tinta bg-evaluacion-suave border-l-[5px] border-evaluacion p-3">
              Este formulario aún no está conectado a la base de datos del
              proyecto (falta configurar Firebase). Ver README.md para
              activarlo.
            </p>
          )}

          {status === "error" && (
            <p className="text-sm text-critico font-semibold">No se pudo enviar: {errorMsg}</p>
          )}

          <button
            type="submit"
            disabled={status === "submitting"}
            className="w-full sm:w-auto bg-critico text-white font-bold px-5 py-3 hover:bg-tinta disabled:opacity-60"
          >
            {status === "submitting" ? "Enviando…" : "Enviar reporte"}
          </button>
        </form>
      )}
    </div>
  );
}
