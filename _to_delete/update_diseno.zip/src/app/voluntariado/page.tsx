"use client";

import { useState, type FormEvent } from "react";
import { useCrisisForm } from "@/lib/useCrisisForm";
import { departamentos } from "@/lib/data";

const PERFILES = [
  "Médico / salud",
  "Rescatista / USAR",
  "Transporte / logística",
  "Psicosocial / salud mental",
  "Traducción / comunicación",
  "Otro",
];

export default function VoluntariadoPage() {
  const { status, errorMsg, submit, isFirebaseConfigured } = useCrisisForm("voluntariado");
  const [perfil, setPerfil] = useState(PERFILES[0]);
  const [departamento, setDepartamento] = useState(departamentos[0]?.id ?? "");

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    submit({
      perfil,
      departamento,
      disponibilidad: form.get("disponibilidad"),
      contacto: form.get("contacto"),
      nombre: form.get("nombre"),
    });
  }

  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-extrabold text-tinta mb-2">Voluntariado</h1>
      <p className="text-tinta-3 mb-6">
        Regístrate para ofrecer ayuda. Recuerda que la coordinación oficial
        de voluntarios la lideran Cruz Roja, Bomberos y la Alcaldía; este
        registro alimenta esa coordinación.
      </p>

      {status === "success" ? (
        <div className="bg-operativo-suave border-l-[5px] border-operativo text-tinta p-5">
          Gracias por ofrecerte como voluntario. El equipo coordinador se
          pondrá en contacto si tu perfil encaja con una necesidad activa.
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-semibold mb-1 text-tinta" htmlFor="nombre">Nombre</label>
            <input
              id="nombre"
              name="nombre"
              type="text"
              required
              className="w-full border border-tinta px-3 py-2 bg-fondo text-tinta"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold mb-1 text-tinta" htmlFor="perfil">Tipo de ayuda que puedes ofrecer</label>
            <select
              id="perfil"
              value={perfil}
              onChange={(e) => setPerfil(e.target.value)}
              className="w-full border border-tinta px-3 py-2 bg-fondo text-tinta"
            >
              {PERFILES.map((p) => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-sm font-semibold mb-1 text-tinta" htmlFor="departamento">Departamento donde puedes ayudar</label>
            <select
              id="departamento"
              value={departamento}
              onChange={(e) => setDepartamento(e.target.value)}
              className="w-full border border-tinta px-3 py-2 bg-fondo text-tinta"
            >
              {departamentos.map((d) => <option key={d.id} value={d.id}>{d.nombre}</option>)}
            </select>
          </div>

          <div>
            <label className="block text-sm font-semibold mb-1 text-tinta" htmlFor="disponibilidad">Disponibilidad</label>
            <input
              id="disponibilidad"
              name="disponibilidad"
              type="text"
              placeholder="Ej: fines de semana, tiempo completo esta semana…"
              className="w-full border border-tinta px-3 py-2 bg-fondo text-tinta"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold mb-1 text-tinta" htmlFor="contacto">Contacto</label>
            <input
              id="contacto"
              name="contacto"
              type="text"
              required
              placeholder="Teléfono o correo"
              className="w-full border border-tinta px-3 py-2 bg-fondo text-tinta"
            />
          </div>

          {!isFirebaseConfigured && (
            <p className="text-xs text-tinta bg-evaluacion-suave border-l-[5px] border-evaluacion p-3">
              Este formulario aún no está conectado a la base de datos del
              proyecto (falta configurar Firebase). Ver README.md para
              activarlo.
            </p>
          )}

          {status === "error" && (
            <p className="text-sm text-critico font-semibold">No se pudo enviar: {errorMsg}</p>
          )}

          <button
            type="submit"
            disabled={status === "submitting"}
            className="w-full sm:w-auto bg-tinta text-white font-bold px-5 py-3 hover:bg-tinta-2 disabled:opacity-60"
          >
            {status === "submitting" ? "Enviando…" : "Registrarme"}
          </button>
        </form>
      )}
    </div>
  );
}
