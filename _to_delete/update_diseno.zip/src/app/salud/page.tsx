import type { Metadata } from "next";
import SourceNote from "@/components/SourceNote";
import { hospitales } from "@/lib/data";

export const metadata: Metadata = {
  title: "Estado de la red hospitalaria",
};

const ESTADO_TONE: Record<string, string> = {
  Evacuada: "bg-critico text-white",
  Inoperativa: "bg-critico text-white",
  "Daño grave": "bg-critico text-white",
  "Saturado (100%)": "bg-evaluacion text-white",
  "En evaluación": "bg-evaluacion text-white",
  "Afectación media": "bg-evaluacion text-white",
  "Afectación técnica": "bg-evaluacion text-white",
  "Afectación estructural": "bg-evaluacion text-white",
};

export default function SaludPage() {
  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-extrabold text-tinta mb-2">Estado de la red hospitalaria</h1>
      <p className="text-tinta-3 mb-6 max-w-2xl">
        Resumen de instituciones de salud afectadas, evacuadas o en
        evaluación en las zonas del sismo.
      </p>

      <div className="overflow-x-auto border border-linea mb-8">
        <table className="w-full text-sm">
          <thead>
            <tr>
              <th>Ciudad / Región</th>
              <th className="text-center">Daño grave / Evacuadas</th>
              <th className="text-center">En evaluación / Saturadas</th>
              <th className="text-center">Total</th>
            </tr>
          </thead>
          <tbody>
            {hospitales.resumen_por_ciudad.map((r) => (
              <tr key={r.ciudad}>
                <td className="font-bold text-tinta">{r.ciudad}</td>
                <td className="text-center">{r.dano_grave_evacuadas}</td>
                <td className="text-center">{r.en_evaluacion_saturadas}</td>
                <td className="text-center font-bold">{r.total}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {hospitales.necesidades_urgentes.length > 0 && (
        <div className="bg-critico-suave border-l-[5px] border-critico p-5 mb-8">
          <h2 className="font-bold text-tinta mb-2">Necesidades urgentes</h2>
          <ul className="space-y-1 text-tinta">
            {hospitales.necesidades_urgentes.map((n, i) => (
              <li key={i}>
                <strong>{n.zona}:</strong> {n.necesidad} — {n.responsable}
              </li>
            ))}
          </ul>
        </div>
      )}

      <h2 className="text-lg font-bold text-tinta mb-3">Instituciones por estado</h2>
      <div className="grid sm:grid-cols-2 gap-3">
        {hospitales.instituciones.map((inst) => (
          <div key={inst.nombre} className="border border-linea p-4">
            <div className="flex items-start justify-between gap-2">
              <span className="font-bold text-tinta">{inst.nombre}</span>
              <span className={`text-[11px] font-bold uppercase tracking-wide px-2 py-0.5 shrink-0 ${ESTADO_TONE[inst.estado] ?? "bg-gris text-white"}`}>
                {inst.estado}
              </span>
            </div>
            <div className="text-xs text-gris mt-1">{inst.ciudad}</div>
            <p className="text-sm text-tinta-3 mt-1">{inst.detalle}</p>
          </div>
        ))}
      </div>

      <div className="mt-6">
        <SourceNote fuente={hospitales.fuente} corte={hospitales.corte} />
      </div>
    </div>
  );
}
