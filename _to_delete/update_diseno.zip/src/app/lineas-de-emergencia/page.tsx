import type { Metadata } from "next";
import { lineas } from "@/lib/data";

export const metadata: Metadata = {
  title: "Líneas de emergencia",
};

export default function LineasPage() {
  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      <h1 className="text-2xl font-extrabold text-tinta mb-2">Líneas de emergencia</h1>
      <p className="text-tinta-3 mb-6 max-w-2xl">
        Guarda estos números. Si hay riesgo de vida, llama primero antes de
        usar cualquier formulario en esta web.
      </p>

      <div className="grid sm:grid-cols-2 gap-4">
        {lineas.map((l) => (
          <div key={l.nombre} className="border-l-[5px] border-critico bg-fondo-2 p-5">
            <div className="text-3xl font-bold text-critico tabular-nums">{l.numero}</div>
            <div className="font-bold mt-1 text-tinta">{l.nombre}</div>
            <div className="text-xs text-gris mt-1">{l.cobertura}</div>
            {l.nota && <p className="text-xs text-gris mt-2">{l.nota}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}
